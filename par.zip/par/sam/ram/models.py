from django.db import models

# Create your models here.
CATEGORY_CHOICES = (
    ('ap','apple'),
    ('xi','xiomi'),
    ('sm','sumsung'),
)

class Product(models.Model):
    title=models.CharField(max_length=100)
    selling_price=models.FloatField(default=0)
    discounted_price=models.FloatField(default=0)
    description=models.CharField(max_length=500)
    category=models.CharField(max_length=2,choices=CATEGORY_CHOICES)
    product_image=models.ImageField(upload_to="products")

    def __str__(self):
        return self.title