from django.apps import AppConfig


class KarConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kar'
